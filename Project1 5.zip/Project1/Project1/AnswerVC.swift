//
//  AnswerVC.swift
//  Project1
//
//  Created by NBT on 26/06/23.
//

import UIKit

class AnswerVC: UIViewController {
    var nocurrect = Int()
    var total = Int()
    
    @IBOutlet weak var shareR: UIButton!
    // The text you want to share
    @IBOutlet weak var playA: UIButton!
    
    @IBOutlet weak var resultLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        getResult()
        playA.layer.cornerRadius = 10
        shareR.layer.cornerRadius = 10
        resultLbl.text = "you got   \(nocurrect) out of \(total) Correct"
        //let texttoShare = "Check out the test original for \(String(describing: resultLbl.text))"
        //var items: [Any] = [textToShare ?? ""]
        var percentRight = Double(nocurrect) / Double(total)
        percentRight *= 100
        var title = ""
        if(percentRight < 40){
            title = "Not good"
        }else if(percentRight < 70){
            title = "Almost"
        }else{
            title = "Good job"
        }
        titleLbl.text = title
        
    }
   // private let texttoShare = resultLbl.text
    private var texttoShare: String?
    func getResult() {
        resultLbl.text = "you got \(nocurrect) out of \(total) Correct"
        texttoShare = resultLbl.text
    }

    private func presentActionSheet(_ vc: VisualActivityViewController, from view: UIView) {
        if UIDevice.current.userInterfaceIdiom == .pad {
            vc.popoverPresentationController?.sourceView = view
            vc.popoverPresentationController?.sourceRect = view.bounds
            vc.popoverPresentationController?.permittedArrowDirections = [.right, .left]
        }
                present(vc, animated: true, completion: nil)

    }
    
    @IBAction func shareresult(_ sender: UIButton) {
//        let vc = VisualActivityViewController(uilable: resultLbl.self)
//        vc.previewNumberOfLines = 10
        let vc = VisualActivityViewController(text: texttoShare ?? "")
        vc.previewNumberOfLines = 10
        
        presentActionSheet(vc, from: sender)
    }
    
    @IBAction func playAgain(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    @IBAction func b1(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        
    }
    
    
    

}
