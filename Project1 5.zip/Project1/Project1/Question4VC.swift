//
//  Question4VC.swift
//  Project1
//
//  Created by NBT on 25/06/23.
//

import UIKit
import AVFoundation

class Question4VC: UIViewController {

    @IBOutlet weak var nextb: UIButton!
    @IBOutlet weak var btn4: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var qLBL: UILabel!
    @IBOutlet weak var btn1: UIButton!
    var clickSoundPlayer: AVAudioPlayer?
    var currentQuestionIndex = 0
    var noCurrect = 0
    var numberOfCurrectQustions = 0
    var answerSelected = false
        var isCorrectAnswer = false
    
    let questions = [
        Question(
            text: "1. Total no. of players playing on the pitch in a hockey match is?",
            options: ["A. 22",
                      
                      "B. 16",

                     " C. 20",

                      "D. 18"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "2. Which player is allowed to touch the ball with his feet during a Hockey match?",
            options: ["A. Goalkeeper",
                      
                      "B. Defender",

                      "C. Centre-forward",

                      "D. Winger"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "3. The dimensions of a Hockey field are?",
            options: ["A. 91.4m X 55m",
                      
                      "B. 92m X 55m",

                      "C. 92.5m X 56m",

                      "D. 91.4m X 56m"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "4. What are the dimensions of the goal at each end of the hockey field?",
            options: ["A. 2.14m X 3.66m",
                      
                      "B. 2.15m X 3.66m",

                      "C. 2.15m X 3.7m",

                      "D. 2.14m X 3.7m"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "5. The distance between thepenalty spot and the goal is?",
            options: ["A. 6yrds",
                      
                      "B. 5yrds",

                      "C. 8yrds",

                      "D. 7yrds"],
            correctAnswerIndex: 3
        ),
        Question(
            text: "6.  The shooting circle in a Hockey field is?",
            options: ["A. 16yrd from the baseline",
                      
                      "B. 18yrd from the baseline",

                      "C. 17yrd from the baseline",

                      "D. 15yrd from the baseline"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "7. The limit on numbers of substitutions per game is?",
            options: ["A. 5",
                      
                      "B. 7",

                      "C. 9",

                      "D. No limit"
                      ],
            correctAnswerIndex: 3
        ),
        Question(
            text: "8. No. of field empires in a match is?",
            options: ["A. 1",
                      
                      "B. 2",

                      "C. 3",

                      "D. 4"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "9. Each half in a hockey game consist of?",
            options: ["A. 30mins",
                      
                      "B. 35mins",

                      "C. 40mins",

                      "D. 45mins"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "5. How long is the half break between two halves of a hockey match?",
            options: ["A. 5mins",
                      
                      "B. 10mins",

                      "C. 12mins",

                      "D. 15mins"],
            correctAnswerIndex: 1
        )
        
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        nextb.layer.cornerRadius = 8
        showQuestion(at: currentQuestionIndex)
        nextb.layer.cornerRadius = 8
        btn1.layer.borderColor = UIColor.white.cgColor
        btn1.layer.borderWidth = 1.0
        btn1.layer.cornerRadius = 8
        btn2.layer.borderColor = UIColor.white.cgColor
        btn2.layer.borderWidth = 1.0
        btn2.layer.cornerRadius = 8
        btn3.layer.borderColor = UIColor.white.cgColor
        btn3.layer.borderWidth = 1.0
        btn3.layer.cornerRadius = 8
        btn4.layer.borderColor = UIColor.white.cgColor
        btn4.layer.borderWidth = 1.0
        btn4.layer.cornerRadius = 8
    }
    
    @IBAction func back5(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func bnext(_ sender: UIButton) {
        if !answerSelected {
            // Show alert
            let alert = UIAlertController(title: "Select One Option", message: "Please select one option before moving to the next question.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        }
        setupClickSound()
        reset()
        let selectedAnswerIndex = sender.tag
        checkAnswer(selectedAnswerIndex)
        
        // Move to the next question after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.currentQuestionIndex += 1
            if self.currentQuestionIndex < self.questions.count {
                self.showQuestion(at: self.currentQuestionIndex)
            } else {
                self.showResult()
            }
        }
        
    }
    func reset(){
        btn1.backgroundColor = .clear
        btn2.backgroundColor = .clear
        btn3.backgroundColor = .clear
        btn4.backgroundColor = .clear
        btn1.tintColor = .white
        btn2.tintColor = .white
        btn3.tintColor = .white
        btn4.tintColor = .white
        answerSelected = false
    }
    func setupClickSound() {
        guard let soundURL = Bundle.main.url(forResource: "clickSound", withExtension: "wav") else {
            return
        }
        
        do {
            clickSoundPlayer = try AVAudioPlayer(contentsOf: soundURL)
            clickSoundPlayer?.prepareToPlay()
        } catch {
            print("Error loading sound file: \(error.localizedDescription)")
        }
    }
    func playClickSound() {
        clickSoundPlayer?.play()
    }
    

    func showQuestion(at index: Int) {
        let question1 = questions[index]
        qLBL.text = question1.text
        btn1.setTitle(question1.options[0], for: .normal)
        btn2.setTitle(question1.options[1], for: .normal)
        btn3.setTitle(question1.options[2], for: .normal)
        btn4.setTitle(question1.options[3], for: .normal)
        
    }
    func checkAnswer(_ selectedAnswerIndex: Int) {
        let question = questions[currentQuestionIndex]
        if selectedAnswerIndex == question.correctAnswerIndex {
            // Correct answer
            print("Correct!")
            numberOfCurrectQustions += 1
        } else {
            // Incorrect answer
            print("Incorrect!")
        }
    }
    
    func showResult() {
        // Display the final score or any concluding message
        print("Quiz completed!")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AnswerVC") as! AnswerVC
        vc.nocurrect = numberOfCurrectQustions
        vc.total = questions.count
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    @IBAction func b1(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        btn1.backgroundColor = .blue
        btn1.tintColor = .white
        answerSelected = true
    }
    
    @IBAction func b2(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        btn2.backgroundColor = .blue
        btn2.tintColor = .white
        answerSelected = true
    }
    
    @IBAction func b3(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        btn3.backgroundColor = .blue
        btn3.tintColor = .white
        answerSelected = true
    }
    @IBAction func b4(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        btn4.backgroundColor = .blue
        btn4.tintColor = .white
        answerSelected = true
    }

}
