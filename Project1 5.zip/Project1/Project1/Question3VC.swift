//
//  Question3VC.swift
//  Project1
//
//  Created by NBT on 25/06/23.
//

import UIKit
import AVFoundation

class Question3VC: UIViewController {
    
    @IBOutlet weak var nextBT: UIButton!
    @IBOutlet weak var optionD: UIButton!
    @IBOutlet weak var optionc: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var QuestionL: UILabel!
    var clickSoundPlayer: AVAudioPlayer?
    var currentQuestionIndex = 0
    var noCurrect = 0
    var numberOfCurrectQustions = 0
    var answerSelected = false
    var isCorrectAnswer = false
    
    let questions = [
        Question(
            text: "1. How many penalties are usually taken in a penalty shoot-out?",
            options: ["A. 30",
                      "B. 29",
                      "C. 28",
                      "D. 30"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "2. Who invented basketball?",
            options: ["A. Dr. James Naismith",
                      "B. Abner Doubleday",
                      "C. William Gilbert",
                      "D. Montevideo Wanderers"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "3. Which ancient game of South America is similar to basketball?",
            options: ["A. Pak-Tapak", "B. Pok-Tapok", "C. Pik-tapik", "D. Pak-Tapak"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "4. What is the height of the basketball hoop?",
            options: ["A. 10 feet", "B. 11 feet", "C. 9 feet", "D. 12 feet"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "5. When was FIBA fromed?",
            options: ["A. 1933", "B. 1936", "C. 1932", "D. 1930"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "6. Which country has the highest number of olympic titles for men’s basketball?",
            options: ["A. USA", "B. Spain", "C. Canada", "D. India"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "7. How is 'scoring a point' usually called?",
            options: ["A. The basket", "B. Touchdown", "C. Home-run", "D. Venus"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "8. How many players form the basketball team along with substitutes?",
            options: ["A. 7", "B. 5", "C. 12", "D. 9"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "9. Who is the tallest player in the international basketball?",
            options: ["A. Suleiman Ali Nashnush", "B. Sim Bhullar", "C. Manute Bol", "D. Rome"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "10. Which country won the first women's world championship?",
            options: ["A. USA", "B. China", "C. Russia", "D. Rome"],
            correctAnswerIndex: 1
        )
        
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        nextBT.layer.cornerRadius = 8
        showQuestion(at: currentQuestionIndex)
        nextBT.layer.cornerRadius = 8
        optionA.layer.borderColor = UIColor.black.cgColor
        optionA.layer.borderWidth = 1.0
        optionA.layer.cornerRadius = 8
        optionB.layer.borderColor = UIColor.black.cgColor
        optionB.layer.borderWidth = 1.0
        optionB.layer.cornerRadius = 8
        optionc.layer.borderColor = UIColor.black.cgColor
        optionc.layer.borderWidth = 1.0
        optionc.layer.cornerRadius = 8
        optionD.layer.borderColor = UIColor.black.cgColor
        optionD.layer.borderWidth = 1.0
        optionD.layer.cornerRadius = 8
    }
    
    @IBAction func back3(_ sender: Any) {
        self.dismiss(animated: true)
    }
    @IBAction func bNext(_ sender: UIButton) {
        if !answerSelected {
            // Show alert
            let alert = UIAlertController(title: "Select One Option", message: "Please select one option before moving to the next question.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        }
        setupClickSound()
        reset()
        let selectedAnswerIndex = sender.tag
        checkAnswer(selectedAnswerIndex)
        
        // Move to the next question after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.currentQuestionIndex += 1
            if self.currentQuestionIndex < self.questions.count {
                self.showQuestion(at: self.currentQuestionIndex)
            } else {
                self.showResult()
            }
        }
      
    }
    func setupClickSound() {
        guard let soundURL = Bundle.main.url(forResource: "clickSound", withExtension: "wav") else {
            return
        }
        
        do {
            clickSoundPlayer = try AVAudioPlayer(contentsOf: soundURL)
            clickSoundPlayer?.prepareToPlay()
        } catch {
            print("Error loading sound file: \(error.localizedDescription)")
        }
    }
    func playClickSound() {
        clickSoundPlayer?.play()
    }
    func reset(){
        optionA.backgroundColor = .clear
        optionB.backgroundColor = .clear
        optionc.backgroundColor = .clear
        optionD.backgroundColor = .clear
        optionA.tintColor = .black
        optionB.tintColor = .black
        optionc.tintColor = .black
        optionD.tintColor = .black
        answerSelected = false
    }
    

    func showQuestion(at index: Int) {
        let question1 = questions[index]
        QuestionL.text = question1.text
        optionA.setTitle(question1.options[0], for: .normal)
        optionB.setTitle(question1.options[1], for: .normal)
        optionc.setTitle(question1.options[2], for: .normal)
        optionD.setTitle(question1.options[3], for: .normal)
        
    }
    func checkAnswer(_ selectedAnswerIndex: Int) {
        let question = questions[currentQuestionIndex]
        if selectedAnswerIndex == question.correctAnswerIndex {
            // Correct answer
            print("Correct!")
            numberOfCurrectQustions += 1
        } else {
            // Incorrect answer
            print("Incorrect!")
        }
    }
    
    func showResult() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AnswerVC") as! AnswerVC
        vc.nocurrect = numberOfCurrectQustions
        vc.total = questions.count
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        // Display the final score or any concluding message
        print("Quiz completed!")
    }

    
    @IBAction func b1(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionA.backgroundColor = .blue
        optionA.tintColor = .white
    }
    
    @IBAction func b2(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionB.backgroundColor = .blue
        optionB.tintColor = .white
    }
    
    @IBAction func b3(_ sender: Any) {
        reset()
        answerSelected = true
        optionc.backgroundColor = .blue
        optionc.tintColor = .white
    }
    @IBAction func b4(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionD.backgroundColor = .blue
        optionD.tintColor = .white
    }

}
