//
//  Question5VC.swift
//  Project1
//
//  Created by NBT on 25/06/23.
//

import UIKit
import AVFoundation

class Question5VC: UIViewController {
    
    @IBOutlet weak var nextb: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var qlbl1: UILabel!
    var clickSoundPlayer: AVAudioPlayer?
    var currentQuestionIndex = 0
    var noCurrect = 0
    var numberOfCurrectQustions = 0
    var answerSelected = false
        var isCorrectAnswer = false
    
    let questions = [
        Question(
            text: "1. Which of the following words refers to a swimming style?",
            options: ["A. A pull", "B. A kick", "C. A stroke", "D. A Rome"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "2. How many strokes are often performed in international swimming competitions?",
            options: ["A. 3", "B. 4", "C. 5", "D. 6"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "3. Which of the following is not a swimming stroke?",
            options: ["A. Frontstroke", "B. Breaststroke", "C. Backstroke", "D. Michelangelo"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "4. In international team races, how many swimmers are there in each team?",
            options: ["A. 4", "B. 6", "C. 8", "D. 8"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "5. Which country has won the most medals in swimming in the Summer Olympics Games?",
            options: ["A. China", "B. The United States", "C. Australia", "D. Rome"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "6. At which age did Australian swimmer Ian Thorpe become the youngest world champion?",
            options: ["A. 15", "B. 17", "C. 19", "D. 21"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "7. When did swimming first become part of the modern Olympic Summer Games?",
            options: ["A. 1896", "B. 1926", "C. 1934", "D. 1920"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "8. Which of the following devices is used to record swimmers’ times at major competitions?",
            options: ["A. Stop watches", "B. Touch pads", "C. GPS timers", "D. Non of these"],
            correctAnswerIndex: 2
        ),
        Question(
            text: "9.  What is the position of the face in the water in backstroke?",
            options: ["A. Face up", "B. Face down", "C. Alternating between up and down", "D. Rome"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "10. Which is often considered to be the most difficult stroke in swimming?",
            options: ["A. Breaststroke", "B. Backstroke", "C. Butterfly", "D. Rome"],
            correctAnswerIndex: 1
        )
        
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showQuestion(at: currentQuestionIndex)
        nextb.layer.cornerRadius = 8
        b1.layer.borderColor = UIColor.black.cgColor
        b1.layer.borderWidth = 1.0
        b1.layer.cornerRadius = 8
        b2.layer.borderColor = UIColor.black.cgColor
        b2.layer.borderWidth = 1.0
        b2.layer.cornerRadius = 8
        b3.layer.borderColor = UIColor.black.cgColor
        b3.layer.borderWidth = 1.0
        b3.layer.cornerRadius = 8
        b4.layer.borderColor = UIColor.black.cgColor
        b4.layer.borderWidth = 1.0
        b4.layer.cornerRadius = 8
    }
    func setupClickSound() {
        guard let soundURL = Bundle.main.url(forResource: "clickSound", withExtension: "wav") else {
            return
        }
        
        do {
            clickSoundPlayer = try AVAudioPlayer(contentsOf: soundURL)
            clickSoundPlayer?.prepareToPlay()
        } catch {
            print("Error loading sound file: \(error.localizedDescription)")
        }
    }
    func playClickSound() {
        clickSoundPlayer?.play()
    }
    
    
    
    @IBAction func back6(_ sender: Any) {
        self.dismiss(animated: true)
    }
    @IBAction func bnext(_ sender: UIButton) {
        if !answerSelected {
            // Show alert
            let alert = UIAlertController(title: "Select One Option", message: "Please select one option before moving to the next question.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        }
        setupClickSound()
        reset()
        let selectedAnswerIndex = sender.tag
        checkAnswer(selectedAnswerIndex)
        
        // Move to the next question after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.currentQuestionIndex += 1
            if self.currentQuestionIndex < self.questions.count {
                self.showQuestion(at: self.currentQuestionIndex)
            } else {
                self.showResult()
            }
        }
    }
    func showQuestion(at index: Int) {
        let question1 = questions[index]
        qlbl1.text = question1.text
        b1.setTitle(question1.options[0], for: .normal)
        b2.setTitle(question1.options[1], for: .normal)
        b3.setTitle(question1.options[2], for: .normal)
        b4.setTitle(question1.options[3], for: .normal)
        
    }
    func checkAnswer(_ selectedAnswerIndex: Int) {
        let question = questions[currentQuestionIndex]
        if selectedAnswerIndex == question.correctAnswerIndex {
            // Correct answer
            print("Correct!")
            numberOfCurrectQustions += 1
        } else {
            // Incorrect answer
            print("Incorrect!")
        }
    }
    
    func showResult() {
        // Display the final score or any concluding message
        print("Quiz completed!")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AnswerVC") as! AnswerVC
        vc.nocurrect = numberOfCurrectQustions
        vc.total = questions.count
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    func reset(){
        b1.backgroundColor = .clear
        b2.backgroundColor = .clear
        b3.backgroundColor = .clear
        b4.backgroundColor = .clear
        b1.tintColor = .black
        b2.tintColor = .black
        b3.tintColor = .black
        b4.tintColor = .black
        answerSelected = false
    }
    
    //struct Question1 {
    //    let text: String
    //    let options: [String]
    //    let correctAnswerIndex: Int
    //}
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    @IBAction func b1(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        b1.backgroundColor = .blue
        b1.tintColor = .white
        answerSelected = true
    }
    
    @IBAction func b2(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        b2.backgroundColor = .blue
        b2.tintColor = .white
        answerSelected = true
    }
    
    @IBAction func b3(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        b3.backgroundColor = .blue
        b3.tintColor = .white
        answerSelected = true
    }
    @IBAction func b4(_ sender: Any) {
        reset()
       // p2View1.layer.borderWidth = 3
        b4.backgroundColor = .blue
        b4.tintColor = .white
        answerSelected = true
    }
}
