//
//  MainVC.swift
//  Project1
//
//  Created by NBT on 25/06/23.
//

import UIKit

class MainVC: UIViewController {

    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var B1: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        B1.layer.cornerRadius = 8
        b2.layer.cornerRadius = 8
        b3.layer.cornerRadius = 8
        b4.layer.cornerRadius = 8
        b5.layer.cornerRadius = 8
        
    }
    
    @IBAction func next1(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func next2(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Question2VC") as! Question2VC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)

        
    }
    @IBAction func next3(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Question3VC") as! Question3VC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)

        
    }
    
    @IBAction func next4(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Question4VC") as! Question4VC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        
    }
    
    @IBAction func next5(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Question5VC") as! Question5VC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
