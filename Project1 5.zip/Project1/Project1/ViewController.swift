//
//  ViewController.swift
//  Project1
//
//  Created by NBT on 24/06/23.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var optionButtonA: UIButton!
    @IBOutlet weak var optionButtonB: UIButton!
    @IBOutlet weak var optionButtonC: UIButton!
    @IBOutlet weak var optionButtonD: UIButton!
    var clickSoundPlayer: AVAudioPlayer?
    var currentQuestionIndex = 0
    var noCurrect = 0
    var numberOfCurrectQustions = 0
    var answerSelected = false
        var isCorrectAnswer = false
   // var ans1, ans2, ans3, ans4, ans5, ans6, ans7, ans8, ans9, ans10 : String?
    
    let questions = [
        Question(
            text: "1. Sachin Tendulkar scored world’s first 200 runs in ODI of __ balls.",
            options: ["A. 147",
                      "B. 148",
                      "C. 157",
                      "D. 197"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "2. Where is the sports stadium, ‘Green Park’ located?",
            options: ["A. Kanpur",
                      "B. Jamshedpur",
                      "C. Cutlack",
                      "D. Patiala"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "3. How many overs are played in Twenty20 cricket match?",
            options: ["A. 50",
                      "B. 20",
                      "C. 100",
                      "D. 40"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "4. What is the middle name of Rahul Dravid?",
            options: ["A. Naren",
                      "B. Sharad",
                      "C. Srivatsav",
                      "D. Shyam"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "5. M. Chinnaswamy Stadium located in which State/UT?",
            options: ["A. Karnataka",
                      "B. Madhya Pradesh",
                      "C. Andaman & Nicobar",
                      "D. Kerala"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "6. International governing body of Cricket is?",
            options: ["A. CCI",
                      "B. GCI",
                      "C. LIC",
                      "D. ICC"],
            correctAnswerIndex: 3
        ),
        Question(
            text: "7. Who has taken the highest number of wickets in Test Cricket?",
            options: ["A. Muttiah Muralitharan",
                      "B. Shane Warne",
                      "C. Anil Kumble",
                      "D. Shoaib Akhtar"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "8. Which of the following term related with the game of Cricket ?",
            options: ["A. Grand Slam",
                      "B. Half Nelson",
                      "C. Ashes",
                      "D. Screen"],
            correctAnswerIndex: 2
        ),
        Question(
            text: "9. Dr. Bhupen Hazarika Cricket Stadium located in which State/UT?",
            options: ["A. Karnataka",
                      "B. Assam",
                      "C. Andaman & Nicobar",
                      "D. Jharkhand"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "10. In which city was the Sri Lankan cricket team attacked in March 2009?",
            options: ["A. Dhaka",
                      "B. Lahore",
                      "C. Kabul",
                     " D. Colombo"],
            correctAnswerIndex: 1
        )
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showQuestion(at: currentQuestionIndex)
        nextBtn.layer.cornerRadius = 8
        optionButtonA.layer.borderColor = UIColor.white.cgColor
        optionButtonA.layer.borderWidth = 1.0
        optionButtonA.layer.cornerRadius = 8
        optionButtonB.layer.borderColor = UIColor.white.cgColor
        optionButtonB.layer.borderWidth = 1.0
        optionButtonB.layer.cornerRadius = 8
        optionButtonC.layer.borderColor = UIColor.white.cgColor
        optionButtonC.layer.borderWidth = 1.0
        optionButtonC.layer.cornerRadius = 8
        optionButtonD.layer.borderColor = UIColor.white.cgColor
        optionButtonD.layer.borderWidth = 1.0
        optionButtonD.layer.cornerRadius = 8
        setupClickSound()
    }
    
    @IBAction func optionA(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionButtonA.backgroundColor = .blue
        optionButtonA.tintColor = .white
    }
    
    
    @IBAction func optionB(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionButtonB.backgroundColor = .blue
        optionButtonB.tintColor = .white
    }
    @IBAction func optionC(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionButtonC.backgroundColor = .blue
        optionButtonC.tintColor = .white
    }
    
    @IBAction func optionD(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionButtonD.backgroundColor = .blue
        optionButtonD.tintColor = .white
    }
    @IBAction func back1(_ sender: Any) {
        self.dismiss(animated: true)
    }
    func setupClickSound() {
        guard let soundURL = Bundle.main.url(forResource: "clickSound", withExtension: "wav") else {
            return
        }
        
        do {
            clickSoundPlayer = try AVAudioPlayer(contentsOf: soundURL)
            clickSoundPlayer?.prepareToPlay()
        } catch {
            print("Error loading sound file: \(error.localizedDescription)")
        }
    }
    func reset(){
        optionButtonA.backgroundColor = .clear
        optionButtonB.backgroundColor = .clear
        optionButtonC.backgroundColor = .clear
        optionButtonD.backgroundColor = .clear
        optionButtonA.tintColor = .white
        optionButtonB.tintColor = .white
        optionButtonC.tintColor = .white
        optionButtonD.tintColor = .white
        answerSelected = false
    }

    func playClickSound() {
        clickSoundPlayer?.play()
    }
    
    @IBAction func optionButtonTapped(_ sender: UIButton) {
                if !answerSelected {
                    // Show alert
                    let alert = UIAlertController(title: "Select One Option", message: "Please select one option before moving to the next question.", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
                    alert.addAction(okAction)
                    present(alert, animated: true, completion: nil)
                    return
                }
        reset()
        setupClickSound()
        let selectedAnswerIndex = sender.tag
        checkAnswer(selectedAnswerIndex)
        
        // Move to the next question after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.currentQuestionIndex += 1
        if self.currentQuestionIndex < self.questions.count {
            self.showQuestion(at: self.currentQuestionIndex)
        } else {
            self.showResult()
        }
    }
    
    }
    
    func showQuestion(at index: Int) {
        let question = questions[index]
        questionLabel.text = question.text
        optionButtonA.setTitle(question.options[0], for: .normal)
        optionButtonB.setTitle(question.options[1], for: .normal)
        optionButtonC.setTitle(question.options[2], for: .normal)
        optionButtonD.setTitle(question.options[3], for: .normal)
    }
    
    func checkAnswer(_ selectedAnswerIndex: Int) {
        let question = questions[currentQuestionIndex]
        if selectedAnswerIndex == question.correctAnswerIndex {
            // Correct answer
            print("Correct!")
            numberOfCurrectQustions += 1
            
        } else {
            // Incorrect answer
            print("Incorrect!")
        }
    }
//    if checkAnswer(idx: Int){
//      if(idx == currentQuestion
//    }
//
    func showResult() {
        // Display the final score or any concluding message
        print("Quiz completed!")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AnswerVC") as! AnswerVC
        vc.nocurrect = numberOfCurrectQustions
        vc.total = questions.count
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
}

struct Question {
    let text: String
    let options: [String]
    let correctAnswerIndex: Int
}


