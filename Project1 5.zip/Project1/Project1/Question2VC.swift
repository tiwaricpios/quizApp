//
//  Question2VC.swift
//  Project1
//
//  Created by NBT on 25/06/23.
//

import UIKit
import AVFoundation

class Question2VC: UIViewController {
    
    @IBOutlet weak var nextB: UIButton!
    @IBOutlet weak var optionBA: UIButton!
    
    @IBOutlet weak var optionBD: UIButton!
    @IBOutlet weak var optionBC: UIButton!
    
    @IBOutlet weak var optionBB: UIButton!
    
    @IBOutlet weak var QuestionLbl: UILabel!
    var clickSoundPlayer: AVAudioPlayer?
    var currentQuestionIndex = 0
    var noCurrect = 0
    var numberOfCurrectQustions = 0
    var answerSelected = false
        var isCorrectAnswer = false
    
    let questions = [
        Question(
            text: "1.When was football game invented",
            options: ["A. November 1869", "B. November 6, 1869", "C. November 6, 1865", "D. November 6, 1885"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "2. How many rules are there in football game?",
            options: ["A. 17", "B. 11", "C. 15", "D. 13"],
            correctAnswerIndex: 0
        ),
        Question(
            text: "3. Who has invented the football game?",
            options: ["A. William Hammersley", "B. Walter Camp", "C. F. M. Campbell", "D. Michelangelo"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "4. What country has invented the modern football game?",
            options: ["A. England",
                      "B. Britain",
                     "C. Australia", "D. Rome"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "5. What year Association football and Rugby became famous?",
            options: ["A. 1860s",
                      "B. 1880s",
                      "C. 1870s", "D. 1890s"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "6. When the Federation Internationale de Football Association (FIFA) was founded?",
            options: ["A.May 21, 1906",
                     "B. May 21, 1904",
                      "C. May 20, 1904",
                      "D. May 20, 1905"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "7. Who was the first president of FIFA?",
            options: ["A. Cornelis August Wilhelm Hirschman",
                      "B. Daniel Burley Woolfall",
                      "C. Robert Guerin",
                     "D. Robert Guerin"],
                     
            correctAnswerIndex: 0
        ),
        Question(
            text: "8. Who is the current president of FIFA?",
            options: ["A. Gianni Infantino",
                      "B. Sepp Blatter",
                      "C. Issa Hayatou",
                     "D. Issa Hayatou"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "9. What is the time limit of football game?",
            options: ["A. 90 Minutes",
                      "B. 100 Minutes",
                      "C. 1 Hour", "C. 1 Hour"],
            correctAnswerIndex: 1
        ),
        Question(
            text: "10. The size of pitches is allowed to play football game is?",
            options: ["A. 100-120 yards long and 50-80 yards wide",
                      "B. 100-130 yards long and 50-100 yards wide",
                      "C. 90-100 yards long and 60-100 yards wide",
                      "D. 90-100 yards long and 60-100 yards wide"],
            correctAnswerIndex: 1
        )
        
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        showQuestion(at: currentQuestionIndex)
        nextB.layer.cornerRadius = 8
        optionBA.layer.borderColor = UIColor.white.cgColor
        optionBA.layer.borderWidth = 1.0
        optionBA.layer.cornerRadius = 8
        optionBB.layer.borderColor = UIColor.white.cgColor
        optionBB.layer.borderWidth = 1.0
        optionBB.layer.cornerRadius = 8
        optionBC.layer.borderColor = UIColor.white.cgColor
        optionBC.layer.borderWidth = 1.0
        optionBC.layer.cornerRadius = 8
        optionBD.layer.borderColor = UIColor.white.cgColor
        optionBD.layer.borderWidth = 1.0
        optionBD.layer.cornerRadius = 8
        // Do any additional setup after loading the view.
    }
    
    @IBAction func back2(_ sender: Any) {
        self.dismiss(animated: true)
    }
    @IBAction func nextb1(_ sender: UIButton) {
        if !answerSelected {
            // Show alert
            let alert = UIAlertController(title: "Select One Option", message: "Please select one option before moving to the next question.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
            return
        }
        setupClickSound()
        reset()
        let selectedAnswerIndex = sender.tag
        checkAnswer(selectedAnswerIndex)
        
        // Move to the next question after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.currentQuestionIndex += 1
            if self.currentQuestionIndex < self.questions.count {
                self.showQuestion(at: self.currentQuestionIndex)
            } else {
                self.showResult()
            }
        }
    }
    
    @IBAction func b1(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionBA.backgroundColor = .blue
        optionBA.tintColor = .white
    }
    
    @IBAction func b2(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionBB.backgroundColor = .blue
        optionBB.tintColor = .white
    }
    
    @IBAction func b3(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionBC.backgroundColor = .blue
        optionBC.tintColor = .white
    }
    @IBAction func b4(_ sender: Any) {
        reset()
        answerSelected = true
       // p2View1.layer.borderWidth = 3
        optionBD.backgroundColor = .blue
        optionBD.tintColor = .white
    }
    
    
    
    
    func reset(){
        optionBA.backgroundColor = .clear
        optionBB.backgroundColor = .clear
        optionBC.backgroundColor = .clear
        optionBD.backgroundColor = .clear
        optionBA.tintColor = .white
        optionBB.tintColor = .white
        optionBC.tintColor = .white
        optionBD.tintColor = .white
        answerSelected = false
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func setupClickSound() {
        guard let soundURL = Bundle.main.url(forResource: "clickSound", withExtension: "wav") else {
            return
        }
        
        do {
            clickSoundPlayer = try AVAudioPlayer(contentsOf: soundURL)
            clickSoundPlayer?.prepareToPlay()
        } catch {
            print("Error loading sound file: \(error.localizedDescription)")
        }
    }
    func playClickSound() {
        clickSoundPlayer?.play()
    }
    

    func showQuestion(at index: Int) {
        let question1 = questions[index]
        QuestionLbl.text = question1.text
        optionBA.setTitle(question1.options[0], for: .normal)
        optionBB.setTitle(question1.options[1], for: .normal)
        optionBC.setTitle(question1.options[2], for: .normal)
        optionBD.setTitle(question1.options[3], for: .normal)
        
    }
    func checkAnswer(_ selectedAnswerIndex: Int) {
        let question = questions[currentQuestionIndex]
        if selectedAnswerIndex == question.correctAnswerIndex {
            // Correct answer
            print("Correct!")
            numberOfCurrectQustions += 1
        } else {
            // Incorrect answer
            print("Incorrect!")
        }
    }
    
    func showResult() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AnswerVC") as! AnswerVC
        vc.nocurrect = numberOfCurrectQustions
        vc.total = questions.count
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        print("Quiz completed!")
    }

}
